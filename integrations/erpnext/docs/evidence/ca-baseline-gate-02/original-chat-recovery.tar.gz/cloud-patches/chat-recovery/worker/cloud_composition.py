"""Typed default composition for the Cloud Worker entrypoint."""

from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass, replace
from uuid import UUID, uuid4

import httpx
from agent_core.domain.cloud_scope import OpaqueAuthorityScope
from agent_core.domain.identifiers import ArtifactId, SessionId
from agent_core.domain.sessions import Session
from agent_core.ports import (
    ArtifactObjectStorePort,
    EffectDispatchPort,
    WorkerProjectionTransactionPort,
)
from agent_core.ports.execution_authority import ExecutionAuthorityResolverPort
from agent_core.ports.extensions import ExtensionStore
from agent_runtime import WorkspaceRuntimeResolver
from agent_storage import (
    CloudCompositionSettings,
    PostgresCloudArtifactPayloadStore,
    PostgresControlPlaneStores,
    PostgresWorkspaceControlStore,
    postgres_control_plane_stores,
)
from agent_storage.postgres.extension_snapshots import PostgresExtensionSnapshotStore
from agent_storage.postgres.extensions import PostgresExtensionStore
from zebra_agent_config import MemoryGatewaySettings

from zebra_agent_worker.coverage_composition import CloudCoverageRuntime
from zebra_agent_worker.memory_context_materialization import RankedMemoryContextMaterializer
from zebra_agent_worker.memory_gateway_runtime import (
    MemoryGatewayRuntime,
    compose_memory_gateway_runtime,
    memory_delivery_scope,
)
from zebra_agent_worker.provider_continuation_commit import (
    CloudProviderContinuationCoordinator,
)
from zebra_agent_worker.runtime_instances import InstanceFactory
from zebra_agent_worker.tool_output_artifacts import CloudToolOutputArtifactCoordinator
from zebra_agent_worker.transient_output_runtime import TransientOutputFactory


def _workspace_snapshot_uri(
    artifact_id: ArtifactId,
    digest: str,
    size_bytes: int,
    object_version: str,
) -> str:
    """Encode all immutable object coordinates needed by a later Worker."""

    return f"workspace-snapshot:{artifact_id}/{digest}/{size_bytes}/{object_version}"


def _parse_workspace_snapshot_uri(uri: str) -> tuple[ArtifactId, str, int, str]:
    prefix, separator, body = uri.partition(":")
    if prefix != "workspace-snapshot" or not separator:
        raise ValueError(f"unsupported workspace object uri: {uri}")
    try:
        artifact_text, digest, size_text, object_version = body.split("/", 3)
        artifact_id = ArtifactId(UUID(artifact_text))
        size_bytes = int(size_text)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"invalid workspace object uri: {uri}") from exc
    if not digest or size_bytes < 0 or not object_version:
        raise ValueError(f"invalid workspace object uri: {uri}")
    return artifact_id, digest, size_bytes, object_version


@dataclass(frozen=True, slots=True)
class CloudWorkerComposition:
    """One Cloud authority bundle; it is deliberately not a local store facade."""

    stores: PostgresControlPlaneStores
    effect_dispatch: EffectDispatchPort
    projection_transaction: WorkerProjectionTransactionPort
    deployment_namespace: str
    artifact_factory: Callable[[SessionId], CloudToolOutputArtifactCoordinator] | None
    provider_continuation_factory: Callable[[SessionId], CloudProviderContinuationCoordinator]
    workspace_resolver_factory: Callable[[], WorkspaceRuntimeResolver | None] | None = None
    authority_resolver: ExecutionAuthorityResolverPort | None = None
    authority_scope_provider: Callable[[Session], OpaqueAuthorityScope] | None = None
    dsn: str | None = None
    runtime_instance_factory: InstanceFactory | None = None
    extension_snapshots: PostgresExtensionSnapshotStore | None = None
    extensions: ExtensionStore | None = None
    skill_objects: ArtifactObjectStorePort | None = None
    memory_runtime: MemoryGatewayRuntime | None = None
    coverage_runtime: CloudCoverageRuntime | None = None
    transient_output_factory: TransientOutputFactory | None = None
    erp_workspace_containment: object | None = None


def compose_cloud_worker(
    cloud: CloudCompositionSettings,
    *,
    memory_settings: MemoryGatewaySettings | None = None,
    memory_environ: Mapping[str, str] | None = None,
    memory_http_client: httpx.Client | None = None,
) -> CloudWorkerComposition:
    required_object_operations = (
        "put_if_absent",
        "verify",
        "read_verified",
        "read_version_verified",
        "delete_if_version",
    )
    if any(
        not callable(getattr(cloud.artifact_objects, name, None))
        for name in required_object_operations
    ):
        raise ValueError("cloud Worker requires an immutable Artifact object writer")
    delivery_scope = memory_delivery_scope(
        memory_settings,
        deployment_namespace=cloud.deployment_namespace,
    )
    stores = postgres_control_plane_stores(
        cloud.dsn,
        deployment_namespace=cloud.deployment_namespace,
        memory_cursor_signing_key=cloud.memory_cursor_signing_key,
        artifact_objects=cloud.artifact_objects,
        history_scope=cloud.history_scope,
        continuation_scope=cloud.continuation_scope,
        memory_delivery_scope=delivery_scope,
    )
    memory_runtime = compose_memory_gateway_runtime(
        memory_settings,
        dsn=cloud.dsn,
        deployment_namespace=cloud.deployment_namespace,
        authority=stores.memories,
        scope=delivery_scope,
        environ=memory_environ,
        client=memory_http_client,
    )
    if memory_runtime is not None:
        stores = replace(
            stores,
            context_materialization=RankedMemoryContextMaterializer(
                stores.context_materialization,
                memory_runtime,
            ),
        )
    dispatch = stores.effects
    if not isinstance(stores.artifact_payloads, PostgresCloudArtifactPayloadStore):
        raise ValueError("strict Cloud composition requires native Artifact metadata")
    required_dispatch = (
        "schedule_with_payload",
        "complete_with_payload",
        "mark_uncertain_with_payload",
    )
    if any(not callable(getattr(dispatch, name, None)) for name in required_dispatch):
        raise ValueError("cloud Effect dispatch must atomically link Artifact payloads")
    transaction = stores.worker_projection_transaction

    def artifact_factory(session_id: SessionId) -> CloudToolOutputArtifactCoordinator:
        return CloudToolOutputArtifactCoordinator(
            session_id,
            stores.artifact_payloads,
            cloud.artifact_objects,
        )

    def provider_factory(session_id: SessionId) -> CloudProviderContinuationCoordinator:
        return CloudProviderContinuationCoordinator(
            store=stores.provider_continuations,
            scope=cloud.continuation_scope,
            session_id=session_id,
        )

    import os
    from pathlib import Path

    from agent_runtime import PostgresWorkspaceProvisioner

    from agent_storage.postgres.erp_workspace_policy import ERPWorkspaceContainment, containment_enabled

    workspace_control = PostgresWorkspaceControlStore(
        cloud.dsn, deployment_namespace=stores.deployment_namespace,
    )
    erp_containment = (
        ERPWorkspaceContainment(cloud.dsn, deployment_namespace=stores.deployment_namespace,
                                workspace_control=workspace_control)
        if containment_enabled(stores.deployment_namespace) else None
    )

    from agent_storage.postgres.erp_workspace_policy import private_activation_enabled
    private_active = private_activation_enabled(stores.deployment_namespace)
    if private_active:
        from agent_runtime.erp_private_workspace import PrivateWorkspaceClient, private_enabled
        private_enabled(stores.deployment_namespace)
        private_client = PrivateWorkspaceClient()

    def workspace_resolver_factory() -> WorkspaceRuntimeResolver | None:
        volume_root = os.environ.get("ZEBRA_WORKSPACE_VOLUME_ROOT", "").strip()
        if not volume_root:
            return None
        store = workspace_control

        def read_object(uri: str) -> bytes:
            from agent_core.domain.artifact_objects import ArtifactObjectExpectation

            artifact_id, digest, size_bytes, version = _parse_workspace_snapshot_uri(uri)
            expectation = ArtifactObjectExpectation(
                deployment_namespace=stores.deployment_namespace,
                artifact_id=artifact_id,
                sha256=digest,
                size_bytes=size_bytes,
            )
            return cloud.artifact_objects.read_version_verified(expectation, version)

        def write_object(payload: bytes) -> str:
            from hashlib import sha256 as _sha256

            from agent_core.domain.artifact_objects import (
                ArtifactObjectExpectation,
                ArtifactObjectPutRequest,
            )
            from agent_core.domain.identifiers import ArtifactId as _ArtifactId

            expectation = ArtifactObjectExpectation(
                deployment_namespace=stores.deployment_namespace,
                artifact_id=_ArtifactId(uuid4()),
                sha256=_sha256(payload).hexdigest(),
                size_bytes=len(payload),
            )
            receipt = cloud.artifact_objects.put_if_absent(
                ArtifactObjectPutRequest(expectation=expectation, payload=payload)
            )
            return _workspace_snapshot_uri(
                expectation.artifact_id,
                expectation.sha256,
                expectation.size_bytes,
                receipt.object_version,
            )

        return WorkspaceRuntimeResolver(
            PostgresWorkspaceProvisioner(
                store,
                volume_root=Path(volume_root),
                artifact_reader=read_object,
                snapshot_writer=write_object,
                snapshot_reader=read_object,
                single_root_layout=os.environ.get("ZEBRA_WORKSPACE_VOLUME_LAYOUT", "") == "root",
            ),
            private_guard=private_client.require if private_active else None,
        )

    from hashlib import sha256 as _sha

    from zebra_agent_worker.runtime_authority import TenantScopedAuthorityResolver

    issuer = cloud.history_scope.authority_issuer
    policy_digest = _sha(f"deployment-authority:{issuer}".encode()).hexdigest()
    authority_resolver = TenantScopedAuthorityResolver(
        authority_issuer=issuer,
        policy_ref="policy/deployment-authority@1",
        policy_version="1",
        policy_effective_digest=policy_digest,
    )

    def authority_scope_provider(session: Session) -> OpaqueAuthorityScope:
        return OpaqueAuthorityScope(
            authority_issuer=issuer,
            namespace_id=session.namespace_id or stores.deployment_namespace,
        )

    from agent_core.domain.leases import WorkerLease
    from agent_storage.postgres.runtime_instances import PostgresRuntimeInstances

    def runtime_instance_factory(
        lease: WorkerLease, scope: OpaqueAuthorityScope, workspace: str | None, engine: str
    ) -> PostgresRuntimeInstances:
        return PostgresRuntimeInstances(
            cloud.dsn,
            deployment_namespace=cloud.deployment_namespace,
            scope=scope,
            lease=lease,
            workspace_ref=workspace,
            engine_identity=engine,
        )

    from agent_storage.postgres.erp_chat_readonly import enabled as chat_enabled
    readonly_chat = chat_enabled(stores.deployment_namespace)
    return CloudWorkerComposition(
        stores=stores,
        erp_workspace_containment=erp_containment,
        effect_dispatch=dispatch,
        projection_transaction=transaction,
        deployment_namespace=stores.deployment_namespace,
        artifact_factory=None if readonly_chat else artifact_factory,
        provider_continuation_factory=provider_factory,
        workspace_resolver_factory=None if readonly_chat else workspace_resolver_factory,
        authority_resolver=authority_resolver,
        authority_scope_provider=authority_scope_provider,
        dsn=cloud.dsn,
        runtime_instance_factory=runtime_instance_factory,
        extension_snapshots=PostgresExtensionSnapshotStore(
            cloud.dsn, deployment_namespace=cloud.deployment_namespace
        ),
        extensions=None if readonly_chat else PostgresExtensionStore(
            cloud.dsn, deployment_namespace=cloud.deployment_namespace
        ),
        skill_objects=None if readonly_chat else cloud.artifact_objects,
        memory_runtime=memory_runtime,
        coverage_runtime=None if readonly_chat else CloudCoverageRuntime(
            cloud.dsn, cloud.deployment_namespace, stores.artifact_payloads, cloud.artifact_objects
        ),
    )
